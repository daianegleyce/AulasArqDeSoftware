package br.usjt.usjt_ccp3anmca_jpa_hibernate.test;

import javax.persistence.EntityManager;

import br.usjt.usjt_ccp3anmca_jpa_hibernate.model.JPAUtil;

public class TesteListaTodosJPQL {
	
	public static void main(String[] args) {
		EntityManager manager = JPAUtil.getEntityManager();
	}

}
